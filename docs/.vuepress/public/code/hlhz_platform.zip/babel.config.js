module.exports = {
  presets: [
    '@babel/preset-env',
  ],

  plugins: [
    [
      'component',
      {
        libraryName: 'element-ui',
        // styleLibraryName: '~src/commons/styles/theme/default/styles',
        style: false,
      },
    ],
  ],
};
