/* eslint-disable no-undef */
import chai from 'chai';
import SchemaValidator from '../../../../src/commons/plugins/http/SchemaValidator';

const { assert } = chai;

describe('SchemaValidator', () => {
  it('number - 1', () => {
    const { success } = SchemaValidator.validate(1, 2);

    assert.equal(success, true);
  });
  it('number - 2', () => {
    const { success } = SchemaValidator.validate(1, '2');

    assert.equal(success, false);
  });
  it('string - 1', () => {
    const { success } = SchemaValidator.validate('1', '2');

    assert.equal(success, true);
  });
  it('string - 2', () => {
    const { success } = SchemaValidator.validate('1', 1);

    assert.equal(success, false);
  });
  it('boolean - 1', () => {
    const { success } = SchemaValidator.validate(true, false);

    assert.equal(success, true);
  });
  it('array - 1', () => {
    const { success } = SchemaValidator.validate([], []);

    assert.equal(success, true);
  });
  it('array - 2', () => {
    const { success } = SchemaValidator.validate([], [{}]);

    assert.equal(success, false);
  });
  it('array - 3', () => {
    const { success } = SchemaValidator.validate([{}], [{ name: '2' }]);

    assert.equal(success, false);
  });
  it('array - 4', () => {
    const { success } = SchemaValidator.validate([{ name: '1' }], [{ name: '2' }]);

    assert.equal(success, true);
  });
  it('object - 1', () => {
    const { success } = SchemaValidator.validate(
      { person: [{ name: '1' }] },
      { person: [{ name: '2' }] },
    );

    assert.equal(success, true);
  });
});
