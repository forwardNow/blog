import cloneDeep from 'lodash.clonedeep';
import http from '../../../commons/plugins/http/http';
import store from '../../../store/store';
import userManageApi from './userManage.api';

const userManageService = {
  getList({
    pageIndex = 1,
    pageSize = 10,
    name = '',
  } = {}) {
    const api = cloneDeep(userManageApi.getList);

    const { username } = store.getters;

    api.data = {
      customParam: {
        loginUser: username,
      },
      data: [
        { code: 'c_name', symbol: '=', value: name },
      ],
      page: pageIndex,
      limit: pageSize,
    };

    return http.request(api);
  },
};

export default userManageService;
