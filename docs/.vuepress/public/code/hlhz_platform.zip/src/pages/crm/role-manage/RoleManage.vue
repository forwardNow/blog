<template>
  <DataGrid
    :list="list"
    :total="total"
    @reload="handleReload"
    @selection-change="handleSelectionChange"
  >
    <template #criteria-queries__inputs>
      <DataGridInput
        v-model="criteriaQueries.name"
        label="姓名"
      />

      <DataGridInput
        v-model="criteriaQueries.telephone"
        label="电话"
      />
    </template>

    <template #operate-buttons>
      <el-button
        class="hui-operate-button"
        type="success"
        @click="handleClickAddUserButton"
      >
        新增
      </el-button>
      <el-button
        class="hui-operate-button"
        type="danger"
      >
        删除
      </el-button>
    </template>

    <template #table-columns>
      <el-table-column
        prop="c_dept"
        label="工号"
      />
      <el-table-column
        prop="c_name"
        label="姓名"
      />
      <el-table-column
        prop="dept"
        label="部门"
      />
      <el-table-column
        prop="c_position"
        label="职位"
      />
      <el-table-column
        prop="c_phone"
        label="电话"
      />
      <el-table-column
        prop="c_email"
        label="邮箱"
      />
      <el-table-column
        prop="c_state_name"
        label="状态"
      />
    </template>
  </DataGrid>
</template>
<script>
import DataGrid from '../../../components/data-grid/DataGrid.vue';
import DataGridInput from '../../../components/data-grid/DataGridInput.vue';
import userManageService from '../user-manage/userManage.service';

export default {
  components: {
    DataGrid,
    DataGridInput,
  },

  data() {
    return {
      criteriaQueries: {
        name: '',
        telephone: '',
      },

      list: [],
      total: 100,

      selection: [],
    };
  },

  methods: {
    handleSelectionChange({ selection }) {
      this.selection = selection;
    },

    handleReload(pager) {
      const params = {
        pageIndex: pager.pageIndex,
        pageSize: pager.pageSize,
        name: this.criteriaQueries.name,
      };

      userManageService.getList(params)
        .then((data) => {
          const { count, data: list } = data;

          this.list = list;
          this.total = count;
        })
        .catch((error) => {
          const errorMessage = `获取列表异常: ${error.message || '请联系管理员'}。`;
          this.$message.error(errorMessage);
        });
    },

    handleClickAddUserButton() {

    },
  },
};
</script>
