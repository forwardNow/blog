<template>
  <div
    class="hui-page"
    :class="{'hui-page_collapsed': isCollapse}"
  >
    <div class="hui-page__sidebar">
      <div class="hui-page-sidebar__logo-box">
        <Logo class="hui-page-sidebar__logo" />
      </div>
      <div class="hui-page-sidebar__menu-box">
        <Menu
          class="hui-page-sidebar__menu"
          :is-collapse="isCollapse"
          @selected="handleSelectMenu"
        />
      </div>
      <div
        class="hui-page-sidebar-menu__collapse-button-box"
      >
        <div
          class="hui-page-sidebar-menu__collapse-button"
          :class="{
            'el-icon-s-unfold': true,
            'el-icon-s-fold': !isCollapse
          }"
          :title="isCollapse ? '展开' : '收缩'"
          @click="handleClickMenuToggleButton"
        />
      </div>
    </div>
    <div class="hui-page__main">
      <div class="hui-page__header">
        <div class="hui-page-header__title">
          {{ selectedMenu.c_name }}
        </div>
      </div>
      <div class="hui-page__content">
        <router-view />
      </div>
    </div>
  </div>
</template>
<script>
import Logo from '../../components/logo/Logo.vue';
import Menu from './components/menu/Menu.vue';

export default {
  components: {
    Logo,
    Menu,
  },

  data() {
    return {
      isCollapse: false,
      selectedMenu: {},
    };
  },

  methods: {
    handleClickMenuToggleButton() {
      this.isCollapse = !this.isCollapse;
    },

    handleSelectMenu(menu) {
      this.selectedMenu = menu;
    },
  },
};
</script>
