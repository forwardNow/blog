<template>
  <el-menu
    :default-active="defaultSelectedMenuUrl"
    :collapse="isCollapse"
    @select="handleSelectMenu"
  >
    <el-submenu
      v-for="menu in menuList"
      :key="menu.c_code"
      :index="menu.c_url || menu.c_code"
    >
      <template slot="title">
        <i
          class="el-submenu-title__icon iconfont"
          :class="menu.fontIconClass"
        />
        <span slot="title">{{ menu.c_name }}</span>
      </template>

      <el-menu-item
        v-for="childMenu in menu.children"
        :key="childMenu.c_code"
        :index="childMenu.c_url"
      >
        <span class="hui-page-sidebar-menu__child-menu-icon" />
        <template slot="title">
          <span slot="title">{{ childMenu.c_name }}</span>
        </template>
      </el-menu-item>
    </el-submenu>
  </el-menu>
</template>
<script>
import get from 'lodash.get';
import menuService from '../../../../commons/services/menu.service';

export default {
  props: {
    isCollapse: {
      required: true,
      type: Boolean,
    },
  },
  data() {
    return {
      defaultSelectedMenuUrl: null,
      currentMenuIndex: null,
      originMenuList: [],
      menuList: [],
    };
  },

  async created() {
    const res = await menuService.getCrmMenuList();

    this.setMenuList(res);

    this.setDefaultSelectedMenu();

    this.emitSelectedEvent(this.defaultSelectedMenuUrl);

    this.setRouteByMenu();
  },

  methods: {
    emitSelectedEvent(menuUrl) {
      const menu = this.originMenuList.find((item) => item.c_url === menuUrl);

      this.$emit('selected', menu);
    },

    setMenuList({ originMenuList, rootMenuList }) {
      this.originMenuList = originMenuList;
      this.menuList = rootMenuList;
    },

    setDefaultSelectedMenu() {
      this.defaultSelectedMenuUrl = this.getDefaultMenuUrl();
    },

    setRouteByMenu() {
      const { path: currPath } = this.$route;

      const menuIndex = this.currentMenuIndex || this.defaultSelectedMenuUrl;

      const pathOfSelectedMenu = menuService.getPathByMenuUrl(menuIndex);

      if (currPath === pathOfSelectedMenu) {
        return;
      }

      this.$router.push({ path: pathOfSelectedMenu });
    },

    getDefaultMenuUrl() {
      const { path } = this.$route;

      let menuUrl = menuService.getMenuUrlByPath(path);

      if (!menuUrl) {
        menuUrl = this.getFirstMenu().c_url;
      }

      return menuUrl;
    },

    getFirstMenu() {
      return get(this.menuList, '[0].children[0]', {});
    },

    handleSelectMenu(index/* , indexPath */) {
      this.currentMenuIndex = index;

      this.setRouteByMenu();
      this.emitSelectedEvent(index);
    },
  },
};
</script>
