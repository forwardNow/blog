import cloneDeep from 'lodash.clonedeep';
import http from '../../../commons/plugins/http/http';
import personasTagsApi from './personasTags.api';

const personasTagsService = {
  getList({
    pageIndex = 1,
    pageSize = 10,
    labelName = '',
  } = {}) {
    const api = cloneDeep(personasTagsApi.getList);

    api.data = {
      data: [
        { code: 'c_label_name', symbol: '=', value: labelName },
      ],
      page: pageIndex,
      limit: pageSize,
    };

    return http.request(api);
  },
};

export default personasTagsService;
