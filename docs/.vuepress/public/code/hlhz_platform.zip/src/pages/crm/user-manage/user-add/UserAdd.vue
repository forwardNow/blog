<template>
  <el-dialog
    title="新增用户"
    width="400px"
    :visible.sync="visible"
    :before-close="handleBeforeClose"
  >
    <div>
      <el-form
        label-position="right"
        label-width="48px"
        :model="formModel"
      >
        <el-form-item label="姓名">
          <el-input v-model="formModel.name" />
        </el-form-item>
      </el-form>
    </div>

    <span
      slot="footer"
      class="dialog-footer"
    >
      <el-button @click="handleClickCancelButton">取 消</el-button>
      <el-button
        type="primary"
        @click="handleClickSubmitButton"
      >确 定</el-button>
    </span>
  </el-dialog>
</template>
<script>
export default {
  props: {
    opened: {
      type: Boolean,
      required: true,
    },
  },

  data() {
    return {
      visible: false,

      formModel: {
        name: '',
      },
    };
  },

  watch: {
    opened(val) {
      this.visible = val;
    },
  },

  methods: {
    updateOpenedProp(value) {
      this.$emit('update:opened', value);
    },

    handleBeforeClose() {
      this.close();
    },

    close() {
      this.visible = false;
      this.updateOpenedProp(false);
    },

    handleClickSubmitButton() {
      this.close();
    },
    handleClickCancelButton() {
      this.close();
    },
  },
};
</script>
