import cloneDeep from 'lodash.clonedeep';
import http from '../../../../commons/plugins/http/http';
import userAddApi from './userAdd.api';

const userAddService = {
  getUsers() {
    const api = cloneDeep(userAddApi.getUsers);

    return http.request(api);
  },
};

export default userAddService;
