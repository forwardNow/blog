<template>
  <div>
    画像标签
  </div>
</template>
