<template>
  <DataGrid
    :list="list"
    :total="total"
    @reload="handleReload"
    @selection-change="handleSelectionChange"
  >
    <template #criteria-queries__inputs>
      <DataGridInput
        v-model="criteriaQueries.labelName"
        label="标签名称"
      />
    </template>

    <template #operate-buttons>
      <el-button
        class="hui-operate-button"
        type="success"
        @click="handleClickAddUserButton"
      >
        新增
      </el-button>
      <el-button
        class="hui-operate-button"
        type="danger"
      >
        删除
      </el-button>
    </template>

    <template #table-columns>
      <el-table-column
        prop="c_label_code"
        label="标签编码"
      />
      <el-table-column
        prop="c_label_name"
        label="标签名称"
      />
    </template>
  </DataGrid>
</template>
<script>
import DataGrid from '../../../components/data-grid/DataGrid.vue';
import DataGridInput from '../../../components/data-grid/DataGridInput.vue';
import personasTagsService from './personasTags.service';

export default {
  components: {
    DataGrid,
    DataGridInput,
  },

  data() {
    return {
      criteriaQueries: {
        labelName: '',
      },

      list: [],
      total: 100,

      selection: [],
    };
  },

  methods: {
    handleSelectionChange({ selection }) {
      this.selection = selection;
    },

    handleReload(pager) {
      const params = {
        pageIndex: pager.pageIndex,
        pageSize: pager.pageSize,
        labelName: this.criteriaQueries.labelName,
      };

      personasTagsService.getList(params)
        .then((data) => {
          const { count, data: list } = data;

          this.list = list;
          this.total = count;
        })
        .catch((error) => {
          const errorMessage = `获取列表异常: ${error.message || '请联系管理员'}。`;
          this.$message.error(errorMessage);
        });
    },

    handleClickAddUserButton() {

    },
  },
};
</script>
