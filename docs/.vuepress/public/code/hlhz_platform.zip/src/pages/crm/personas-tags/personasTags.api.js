const personasTagsApi = {
  getList: {
    url: '/hlhz_crm_plus/labelBasic/getList',
    method: 'post',
    data: {},

    $formUrlEncoded: false,

    $schema: {
      requestBody: {
        data: [
          { code: 'c_label_name', value: '', symbol: '=' }],
        page: 1,
        limit: 10,
      },
      responseBody: {
        code: 200,
        msg: '操作成功',
        data: {
          data: [
            { c_label_code: '1', c_label_name: 'test1' }],
          count: 1,
        },
      },
    },
  },
};

export default personasTagsApi;
