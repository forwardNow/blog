<template>
  <div class="hui-card-biz-crud">
    <div class="hui-card-biz-crud__criteria-queries">
      <div class="hui-criteria-queries__inputs">
        <div class="hui-criteria-queries-inputs__item">
          <el-input v-model="criteriaQueries.name">
            <template slot="prepend">
              姓名
            </template>
          </el-input>
        </div>
        <div
          class="hui-criteria-queries-inputs__item"
        >
          <el-input v-model="criteriaQueries.telephone">
            <template slot="prepend">
              电话
            </template>
          </el-input>
        </div>
      </div>
      <div class="hui-criteria-queries__query-button">
        <el-button
          type="primary"
          @click="handleClickSearchButton"
        >
          查询
        </el-button>
      </div>
    </div>
    <div class="hui-card-biz-crud__operate-buttons">
      <el-button
        class="hui-operate-button"
        type="success"
        @click="handleClickAddUserButton"
      >
        新增
      </el-button>
      <el-button
        class="hui-operate-button"
        type="danger"
      >
        删除
      </el-button>
    </div>
    <div class="hui-card-biz-crud__data-grid">
      <div class="hui-data-grid__table">
        <el-table
          :data="list"
          :height="tableHeight"
          :row-class-name="tableRowClassName"
          border
          style="width: 100%"
          @selection-change="handleSelectionChange"
        >
          <el-table-column
            type="index"
            align="center"
            class-name="hui-table-cell_index"
          />
          <el-table-column
            type="selection"
            align="center"
          />
          <el-table-column
            prop="c_dept"
            label="工号"
          />
          <el-table-column
            prop="c_name"
            label="姓名"
          />
          <el-table-column
            prop="dept"
            label="部门"
          />
          <el-table-column
            prop="c_position"
            label="职位"
          />
          <el-table-column
            prop="c_phone"
            label="电话"
          />
          <el-table-column
            prop="c_email"
            label="邮箱"
          />
          <el-table-column
            prop="c_state_name"
            label="状态"
          />
        </el-table>
      </div>
      <div class="hui-data-grid__pagination">
        <el-pagination
          background
          :current-page.sync="pager.pageIndex"
          :page-sizes="pager.pageSizes"
          :page-size="pager.pageSize"
          layout="total, sizes, prev, pager, next, jumper"
          :total="pager.total"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </div>

    <UserAdd :opened.sync="userAddDialogOpened" />
  </div>
</template>
<script>
import tableMixin from '../../../components/data-grid/tableMixin';
import userManageService from './userManage.service';
import UserAdd from './user-add/UserAdd.vue';

export default {
  name: 'UserManage',

  components: {
    UserAdd,
  },

  mixins: [tableMixin],

  data() {
    return {
      userAddDialogOpened: false,

      criteriaQueries: {
        name: '',
        telephone: '',
      },
    };
  },

  methods: {
    request() {
      const params = {
        pageIndex: this.pager.pageIndex,
        pageSize: this.pager.pageSize,
        name: this.criteriaQueries.name,
      };
      return userManageService.getList(params);
    },

    handleClickSearchButton() {
      this.reload();
    },

    handleClickAddUserButton() {
      this.userAddDialogOpened = true;
    },
  },
};
</script>
