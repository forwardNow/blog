<template>
  <div class="hui-card-biz-crud">
    <div class="hui-card-biz-crud__criteria-queries">
      <div class="hui-criteria-queries__inputs">
        <div class="hui-criteria-queries-inputs__item">
          <el-input v-model="criteriaQueries.name">
            <template slot="prepend">
              姓名
            </template>
          </el-input>
        </div>
        <div
          class="hui-criteria-queries-inputs__item"
        >
          <el-input v-model="criteriaQueries.telephone">
            <template slot="prepend">
              电话
            </template>
          </el-input>
        </div>
      </div>
      <div class="hui-criteria-queries__query-button">
        <el-button
          type="primary"
          @click="handleClickSearchButton"
        >
          查询
        </el-button>
      </div>
    </div>

    <div class="hui-card-biz-crud__operate-buttons">
      <el-button
        class="hui-operate-button"
        type="success"
        @click="handleClickAddUserButton"
      >
        新增
      </el-button>
      <el-button
        class="hui-operate-button"
        type="primary"
      >
        编辑
      </el-button>
      <el-button
        class="hui-operate-button"
        type="danger"
      >
        删除
      </el-button>
    </div>

    <div class="hui-card-biz-crud__data-grid">
      <div class="hui-data-grid__table">
        <el-table
          :data="list"
          :height="tableHeight"
          :row-class-name="tableRowClassName"
          border
          style="width: 100%"
          @selection-change="handleSelectionChange"
        >
          <el-table-column
            type="index"
            align="center"
            class-name="hui-table-cell_index"
          />
          <el-table-column
            type="selection"
            align="center"
          />
          <el-table-column
            prop="c_dept"
            label="工号"
          />
          <el-table-column
            prop="c_name"
            label="姓名"
          />
          <el-table-column
            prop="dept"
            label="部门"
          />
          <el-table-column
            prop="c_position"
            label="职位"
          />
          <el-table-column
            prop="c_phone"
            label="电话"
          />
          <el-table-column
            prop="c_email"
            label="邮箱"
          />
          <el-table-column
            prop="c_state_name"
            label="状态"
          />
        </el-table>
      </div>
      <div class="hui-data-grid__pagination">
        <el-pagination
          background
          :current-page.sync="pager.pageIndex"
          :page-sizes="pager.pageSizes"
          :page-size="pager.pageSize"
          layout="total, sizes, prev, pager, next, jumper"
          :total="pager.total"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </div>

    <UserAdd :opened.sync="userAddDialogOpened" />
  </div>
</template>
<script>
import userManageService from './userManage.service';
import UserAdd from './user-add/UserAdd.vue';

export default {
  name: 'UserManage',

  components: {
    UserAdd,
  },

  data() {
    return {
      tableHeight: '200',

      list: [],
      selectedList: [],

      pager: {
        total: 0,
        pageIndex: 1,
        pageSize: 10,

        pageSizes: [10, 20, 50, 100],
      },

      criteriaQueries: {
        name: '',
        telephone: '',
      },

      userAddDialogOpened: false,
    };
  },

  created() {
    this.reload();
  },

  methods: {
    request() {
      const params = {
        pageIndex: this.pager.pageIndex,
        pageSize: this.pager.pageSize,
        name: this.criteriaQueries.name,
      };
      return userManageService.getList(params);
    },

    reload() {
      this.request()
        .then((data) => {
          const { count, data: list } = data;

          this.list = this.formatList(list);
          this.pager.total = count;

          this.resetTableHeight();
        })
        .catch((error) => {
          const errorMessage = `获取列表异常: ${error.message || '请联系管理员'}。`;
          this.$message.error(errorMessage);
        });
    },

    formatList(list) {
      return list.map((item, index) => ({ ...item, $index: index, $selected: false }));
    },

    tableRowClassName({ row }) {
      if (row.$selected) {
        return 'hui-table-row_selected';
      }

      return '';
    },

    handleSelectionChange(selection) {
      this.selectedList = selection;

      const selectedIdx = selection.map((item) => item.$index);

      this.list.forEach((item, index) => {
        // eslint-disable-next-line no-param-reassign
        item.$selected = selectedIdx.includes(item.$index);
        this.$set(this.list, index, item);
      });
    },

    resetTableHeight() {
      this.$nextTick(() => {
        const boxHeight = this.getElementHeight('.hui-card-biz-crud');
        const queriesHeight = this.getElementHeight('.hui-card-biz-crud__criteria-queries');
        const buttonsHeight = this.getElementHeight('.hui-card-biz-crud__operate-buttons');
        const dataTableHeight = this.getElementHeight('.hui-card-biz-crud__data-grid');
        const tableHeight = this.getElementHeight('.hui-data-grid__table');

        this.tableHeight = boxHeight - (queriesHeight + buttonsHeight + dataTableHeight)
            + tableHeight;
      });
    },

    getElementHeight(selector) {
      const elt = document.querySelector(selector);

      const { height } = elt.getBoundingClientRect();

      return height;
    },

    handleSizeChange() {
      this.reload();
    },

    handleCurrentChange() {
      this.reload();
    },

    handleClickSearchButton() {
      this.reload();
    },

    handleClickAddUserButton() {
      this.userAddDialogOpened = true;
    },
  },
};
</script>
