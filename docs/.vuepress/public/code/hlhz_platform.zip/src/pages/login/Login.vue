<template>
  <div class="hlhz-page_login">
    <div class="hlhz-login-panel">
      <div class="hlhz-login-panel__header">
        业务系统登录
      </div>
      <div class="hlhz-login-panel__body">
        <el-form
          ref="loginForm"
          :model="formModel"
          status-icon
          :rules="rules"
          label-width="80px"
          class="hlhz-login-form"
        >
          <el-form-item
            label="账号"
            prop="username"
          >
            <el-input
              v-model="formModel.username"
              type="input"
              autocomplete="off"
            />
          </el-form-item>
          <el-form-item
            label="密码"
            prop="password"
          >
            <el-input
              v-model="formModel.password"
              type="password"
              show-password
              autocomplete="off"
            />
          </el-form-item>
          <el-form-item>
            <el-button
              type="primary"
              class="hlhz-login-form-submit-button"
              @click="handleSubmit()"
            >
              提交
            </el-button>
          </el-form-item>
        </el-form>
      </div>
    </div>
  </div>
</template>
<style lang="scss" src="./login.scss"></style>
<script>
import loginService from './login.service';

export default {
  data() {
    return {
      formModel: {
        username: 'hlhz_admin',
        password: '123456',
      },
      rules: {
        username: [
          { required: true, message: '请输入账号', trigger: ['blur', 'change'] },
        ],
        password: [
          { required: true, message: '请输入密码', trigger: ['blur', 'change'] },
        ],
      },
    };
  },
  methods: {
    handleSubmit() {
      this.$refs.loginForm.validate((valid) => {
        if (!valid) {
          return;
        }

        this.submit();
      });
    },

    submit() {
      const { username, password } = this.formModel;

      loginService.login({ username, password })
        .then((data) => {
          const { token, user } = data;

          this.$store.commit('setToken', { token });
          this.$store.commit('setUser', { user });

          this.$router.push({ path: '/' });
        })
        .catch((error) => {
          const errorMessage = `登录失败: ${error.message || '请联系管理员'}。`;
          this.$message.error(errorMessage);
        });
    },
  },
};
</script>
