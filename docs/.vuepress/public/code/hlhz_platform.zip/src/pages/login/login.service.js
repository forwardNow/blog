import cloneDeep from 'lodash.clonedeep';
import http from '../../commons/plugins/http/http';
import loginApi from './login.api';
import store from '../../store/store';

const loginService = {
  login({ username, password }) {
    const api = cloneDeep(loginApi.login);

    api.data = {
      user: username,
      password,
      clientType: 'pc',
    };

    return http.request(api);
  },

  logout() {
    store.commit('clearSession');

    return Promise.resolve(true);
  },
};

export default loginService;
