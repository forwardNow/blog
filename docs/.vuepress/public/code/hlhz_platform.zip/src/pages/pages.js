export const Login = () => import(
  /* webpackChunkName: "login" */
  './login/Login.vue'
);

export const Home = () => import(
  /* webpackChunkName: "home" */
  './home/Home.vue'
);

export const Crm = () => import(
  /* webpackChunkName: "crm__crm" */
  './crm/Crm.vue'
);

export const CrmUserManage = () => import(
  /* webpackChunkName: "crm__user-manage" */
  './crm/user-manage/UserManage.vue'
);

export const CrmRoleManage = () => import(
  /* webpackChunkName: "crm__role-manage" */
  './crm/role-manage/RoleManage.vue'
);

export const CrmPersonasTags = () => import(
  /* webpackChunkName: "crm__personas-tags" */
  './crm/personas-tags/PersonasTags.vue'
);

export const CrmCustomerManage = () => import(
  /* webpackChunkName: "crm__customer-manage" */
  './crm/customer-manage/CustomerManage.vue'
);

export const CrmCustomerTrack = () => import(
  /* webpackChunkName: "crm__customer-track" */
  './crm/customer-track/CustomerTrack.vue'
);

export const CrmContractManage = () => import(
  /* webpackChunkName: "crm__contract-manage" */
  './crm/contract-manage/ContractManage.vue'
);

export default {};
