import cloneDeep from 'lodash.clonedeep';
import http from '../../commons/plugins/http/http';
import store from '../../store/store';
import homeApi from './home.api';

const homeService = {
  getSystems() {
    const api = cloneDeep(homeApi.getSystems);

    api.data = {
      uuid: store.getters.uuid,
      type: '',
    };

    return http.request(api);
  },
};

export default homeService;
