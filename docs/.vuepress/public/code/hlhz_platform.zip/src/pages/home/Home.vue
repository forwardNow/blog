<template>
  <div class="hlhz-page_home">
    <div class="hlhz-page__header">
      <div class="hlhz-page__logo-box">
        <img
          class="hlhz-page__logo"
          src="./images/logo.png"
          alt=""
        >
      </div>
      <div class="hlhz-page__nav">
        <div
          class="hlhz-nav__button"
          @click="handleClickLogoutButton"
        >
          <span class="hlhz-nav-button__icon el-icon-switch-button" />
          <div class="hlhz-nav-button__text">
            退出
          </div>
        </div>
      </div>
    </div>
    <div class="hlhz-page__body">
      <div class="hlhz-system-list">
        <a
          v-for="item in systemList"
          :key="item.id"
          :href="item.path"
          class="hlhz-system-item"
        >
          <span>{{ item.name }}</span>
        </a>
      </div>
    </div>
  </div>
</template>
<script>
import homeService from './home.service';
import loginService from '../login/login.service';

export default {
  data() {
    return {
      systemList: [],
    };
  },

  created() {
    homeService.getSystems()
      .then((data) => {
        this.systemList = this.formatSystemList(data);
      })
      .catch((e) => {
        const errorMessage = `获取系统列表异常: ${e.message || '请联系管理员'}。`;
        this.$message.error(errorMessage);
      });
  },

  methods: {
    formatSystemList(systemList) {
      return systemList.map((item) => {
        const { c_code: id, c_name: name, c_request_url: url } = item;

        let path = `#/${url}`;

        if (url === 'hlhz_crm_plus') {
          path = '#/crm';
        }

        return {
          id, name, url, path,
        };
      });
    },

    handleClickLogoutButton() {
      loginService.logout().then(() => {
        this.$router.push({ name: 'login' });
      });
    },
  },
};
</script>
<style lang="scss">
.hlhz-page_home {
  display: flex;
  flex-direction: column;
  height: 100vh;
  background: url(./images/bg.jpg) no-repeat;
  background-size: cover;
}

.hlhz-page__header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  height: 70px;
  flex: 0 0 auto;
  background: #2576e7;
}

.hlhz-page__logo-box {
  display: flex;
  align-items: center;
  height: 100%;
}
.hlhz-page__logo {
  margin-left: 40px;
}

.hlhz-page__nav {
  display: flex;
  align-items: center;
}

.hlhz-nav__button {
  display: flex;
  align-items: center;
  margin-right: 40px;
  color: #fff;
  font-size: 16px;
  cursor: pointer;

  &:hover {
    opacity: 0.8;
  }
}

.hlhz-nav-button__icon {
  margin-right: 4px;
}

.hlhz-page__body {
  flex: 1 1 auto;
  height: calc(100% - 70px);
  overflow: auto;
}

.hlhz-system-list {
  display: flex;
  flex-wrap: wrap;
  padding: 20px;
}

.hlhz-system-item {
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 20px;
  width: 270px;
  height: 110px;
  background: url("./images/system_item_bg.png") no-repeat;
  color: #fff;
  cursor: pointer;

  &:hover {
    box-shadow: 0 0 10px rgba(255, 255, 255, 0.1);
  }
}

</style>
