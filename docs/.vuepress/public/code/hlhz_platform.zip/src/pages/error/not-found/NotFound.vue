<template>
  <div class="hlhz-page_404">
    <div class="hlhz-page_404__content">404</div>
  </div>
</template>
<style lang="scss">
.hlhz-page_404 {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 100vh;
}

.hlhz-page_404__content {
  font-size: 64px;
  color: #666;
}
</style>
