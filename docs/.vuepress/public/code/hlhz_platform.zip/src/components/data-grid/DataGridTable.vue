<template>
  <el-table
    :data="formattedList"
    :height="height"
    :row-class-name="tableRowClassName"
    border
    style="width: 100%"
    @selection-change="handleSelectionChange"
  >
    <el-table-column
      type="index"
      align="center"
      class-name="hui-table-cell_index"
    />
    <el-table-column
      type="selection"
      align="center"
    />

    <slot />
  </el-table>
</template>
<script>
export default {
  props: {
    height: {
      type: String,
      default: '200',
    },

    list: {
      type: Array,
      required: true,
    },
  },

  data() {
    return {
      selectedList: [],
      formattedList: [],
    };
  },

  watch: {
    list: {
      immediate: true,
      handler(val) {
        if (!val) {
          return;
        }
        this.formattedList = this.formatList(val);
      },
    },
  },

  methods: {
    formatList(list) {
      return list.map((item, index) => ({ ...item, $index: index, $selected: false }));
    },

    tableRowClassName({ row }) {
      if (row.$selected) {
        return 'hui-table-row_selected';
      }

      return '';
    },

    handleSelectionChange(selection) {
      this.selectedList = selection;

      const selectedIdx = selection.map((item) => item.$index);

      this.formattedList.forEach((item, index) => {
        // eslint-disable-next-line no-param-reassign
        item.$selected = selectedIdx.includes(item.$index);
        this.$set(this.formattedList, index, item);
      });

      this.$emit('selection-change', { selection });
    },
  },
};
</script>
