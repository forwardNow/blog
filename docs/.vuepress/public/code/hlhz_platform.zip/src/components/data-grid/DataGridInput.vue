<template>
  <div class="hui-criteria-queries-inputs__item">
    <el-input
      :value="value"
      @input="handleInput"
    >
      <template slot="prepend">
        {{ label }}
      </template>
    </el-input>
  </div>
</template>
<script>
export default {
  model: {
    prop: 'value',
    event: 'input',
  },

  props: {
    value: {
      type: [String, Number],
      default: '',
    },

    label: {
      type: String,
      required: true,
    },
  },

  data() {
    return {
    };
  },

  methods: {
    handleInput(value) {
      this.$emit('input', value);
    },
  },
};
</script>
