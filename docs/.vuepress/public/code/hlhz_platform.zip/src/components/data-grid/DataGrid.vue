<template>
  <div class="hui-card-biz-crud">
    <div class="hui-card-biz-crud__criteria-queries">
      <div class="hui-criteria-queries__inputs">
        <slot name="criteria-queries__inputs">
          <DataGridInput
            label="姓名"
          />
        </slot>
      </div>

      <div class="hui-criteria-queries__query-button">
        <slot name="criteria-queries__query-button">
          <el-button
            type="primary"
            @click="handleClickSearchButton"
          >
            查询
          </el-button>
        </slot>
      </div>
    </div>

    <div class="hui-card-biz-crud__operate-buttons">
      <slot name="operate-buttons">
        <el-button
          class="hui-operate-button"
          type="success"
        >
          新增
        </el-button>
      </slot>
    </div>

    <div class="hui-card-biz-crud__data-grid">
      <div class="hui-data-grid__table">
        <DataGridTable
          :list="list"
          @selection-change="handleSelectionChange"
        >
          <slot name="table-columns" />
        </DataGridTable>
      </div>
      <div class="hui-data-grid__pagination">
        <el-pagination
          background
          :current-page.sync="pager.pageIndex"
          :page-sizes="pager.pageSizes"
          :page-size="pager.pageSize"
          layout="total, sizes, prev, pager, next, jumper"
          :total="pager.total"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </div>
  </div>
</template>
<script>
import DataGridTable from './DataGridTable.vue';
import DataGridInput from './DataGridInput.vue';

export default {
  components: {
    DataGridTable,
    DataGridInput,
  },
  props: {
    list: {
      type: Array,
      required: true,
    },

    total: {
      type: Number,
      required: true,
    },
  },

  data() {
    return {
      pager: {
        total: 0,
        pageIndex: 1,
        pageSize: 10,

        pageSizes: [10, 20, 50, 100],
      },
    };
  },

  watch: {
    total: {
      immediate: true,
      handler(val) {
        this.pager.total = val;
      },
    },
  },

  created() {
    this.reload();
  },

  methods: {
    handleSelectionChange({ selection }) {
      this.$emit('selection-change', { selection });
    },

    handleClickSearchButton() {
      this.reload();
    },

    reload() {
      const {
        pageIndex,
        pageSize,
      } = this.pager;

      this.$emit('reload', {
        pager: { pageIndex, pageSize },
      });
    },

    handleSizeChange() {
      this.reload();
    },

    handleCurrentChange() {
      this.reload();
    },
  },
};
</script>
