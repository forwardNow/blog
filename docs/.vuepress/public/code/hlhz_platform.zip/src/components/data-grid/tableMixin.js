const tableMixin = {
  data() {
    return {
      tableHeight: '200',

      list: [],
      selectedList: [],

      pager: {
        total: 0,
        pageIndex: 1,
        pageSize: 10,

        pageSizes: [10, 20, 50, 100],
      },
    };
  },

  created() {
    this.reload();
  },

  methods: {
    reload() {
      this.request()
        .then((data) => {
          const { count, data: list } = data;

          this.list = this.formatList(list);
          this.pager.total = count;

          this.resetTableHeight();
        })
        .catch((error) => {
          const errorMessage = `获取列表异常: ${error.message || '请联系管理员'}。`;
          this.$message.error(errorMessage);
        });
    },

    formatList(list) {
      return list.map((item, index) => ({ ...item, $index: index, $selected: false }));
    },

    tableRowClassName({ row }) {
      if (row.$selected) {
        return 'hui-table-row_selected';
      }

      return '';
    },

    handleSelectionChange(selection) {
      this.selectedList = selection;

      const selectedIdx = selection.map((item) => item.$index);

      this.list.forEach((item, index) => {
        // eslint-disable-next-line no-param-reassign
        item.$selected = selectedIdx.includes(item.$index);
        this.$set(this.list, index, item);
      });
    },

    resetTableHeight() {
      this.$nextTick(() => {
        const boxHeight = this.getElementHeight('.hui-card-biz-crud');
        const queriesHeight = this.getElementHeight('.hui-card-biz-crud__criteria-queries');
        const buttonsHeight = this.getElementHeight('.hui-card-biz-crud__operate-buttons');
        const dataTableHeight = this.getElementHeight('.hui-card-biz-crud__data-grid');
        const tableHeight = this.getElementHeight('.hui-data-grid__table');

        this.tableHeight = boxHeight - (queriesHeight + buttonsHeight + dataTableHeight)
          + tableHeight;
      });
    },

    getElementHeight(selector) {
      const elt = document.querySelector(selector);

      const { height } = elt.getBoundingClientRect();

      return height;
    },

    handleSizeChange() {
      this.reload();
    },

    handleCurrentChange() {
      this.reload();
    },
  },
};

export default tableMixin;
