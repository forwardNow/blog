import Vue from 'vue';

import './commons/plugins/polyfill/polyfill';

import './commons/plugins/element-ui/elementUI';
import './commons/styles/styles.scss';

import App from './App.vue';
import router from './router/router';
import store from './store/store';

new Vue({
  router,
  store,
  render: (h) => h(App),
}).$mount('#hlhzApp');
