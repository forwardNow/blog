import NotFound from '../pages/error/not-found/NotFound.vue';

import {
  Login,
  Home,

  Crm,
  CrmUserManage,
  CrmRoleManage,
  CrmPersonasTags,
  CrmCustomerManage,
  CrmCustomerTrack,
  CrmContractManage,
} from '../pages/pages';

export default [
  { path: '/', redirect: '/home' },
  {
    path: '/login', name: 'login', component: Login, meta: { title: '登录' },
  },
  {
    path: '/home', name: 'home', component: Home, meta: { title: '首页' },
  },

  {
    path: '/crm',
    component: Crm,
    children: [
      { path: '/crm/user-manage', component: CrmUserManage, meta: { title: '用户管理' } },
      { path: '/crm/role-manage', component: CrmRoleManage, meta: { title: '角色管理' } },
      { path: '/crm/personas-tags', component: CrmPersonasTags, meta: { title: '画像标签' } },
      { path: '/crm/customer-manage', component: CrmCustomerManage, meta: { title: '客户信息管理' } },
      { path: '/crm/customer-track', component: CrmCustomerTrack, meta: { title: '客户跟进' } },
      { path: '/crm/contract-manage', component: CrmContractManage, meta: { title: '合同管理' } },
    ],
  },
  { path: '*', name: '404', component: NotFound },
];
