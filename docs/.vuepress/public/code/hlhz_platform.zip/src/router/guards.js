import get from 'lodash.get';

import constant from '../commons/configs/constant';
import store from '../store/store';

const { DOCUMENT_TITLE_SUFFIX } = constant;

export function setAfterGuards(router) {
  router.beforeEach((to, from, next) => {
    if (['login', '404'].includes(to.name)) {
      next();
      return;
    }

    if (store.getters.isLogin) {
      next();
      return;
    }

    next({ name: 'login' });
  });
}

export function setBeforeGuards(router) {
  router.afterEach((to /* , from */) => {
    const title = get(to, 'meta.title', '');
    let fullTitle = DOCUMENT_TITLE_SUFFIX;

    if (title) {
      fullTitle = `${title} | ${DOCUMENT_TITLE_SUFFIX}`;
    }

    window.document.title = fullTitle;
  });
}
