/* eslint-disable no-param-reassign */
import localStorageService from '../commons/services/localStorage.service';

export default {
  execute(store) {
    const token = localStorageService.get('token');
    const user = localStorageService.get('user') || {};

    store.state.token = token;
    store.state.user = user;
  },
};
