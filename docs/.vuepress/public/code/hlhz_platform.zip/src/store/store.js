/* eslint-disable no-param-reassign */
import Vue from 'vue';
import Vuex from 'vuex';

import localStorageService from '../commons/services/localStorage.service';
import stateInitialization from './stateInitialization';

Vue.use(Vuex);

const options = {
  state: {
    token: '',
    user: {},
  },

  getters: {
    isLogin: (state) => Boolean(state.token),

    uuid: (state) => state.user.c_uuid,

    username: (state) => state.user.c_user,
  },

  mutations: {
    setToken(state, { token }) {
      state.token = token;

      localStorageService.set('token', token);
    },

    setUser(state, { user }) {
      state.user = user;

      localStorageService.set('user', user);
    },

    clearSession() {
      this.commit('setToken', { token: '' });
      this.commit('setUser', { user: {} });
    },
  },
};

stateInitialization.execute(options);

const store = new Vuex.Store(options);

export default store;
