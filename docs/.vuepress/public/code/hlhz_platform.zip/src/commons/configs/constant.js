import Config from '../../../build/config';

const { ENV } = Config;

// 构建时设置的 ENV
const ENV_FROM_BUILD = process.env.ENV;

const curEnv = ENV_FROM_BUILD || ENV.DEV;

const constant = {
  env: curEnv,

  // 多环境配置
  apiBasePath: {
    [ENV.DEV]: 'http://localhost:3000/hlhz_platform_backend',
    [ENV.TEST]: 'http://127.0.0.1:3000/hlhz_platform_backend',
    [ENV.PROD]: 'http://192.168.1.120:3000/hlhz_platform_backend',
  }[curEnv],

  HTTP_TIMEOUT: 6 * 1000,

  DOCUMENT_TITLE_SUFFIX: '恒力华振',

  LOCAL_STORAGE_KEY: 'HLHZ_STORAGE',

  LOCAL_STORAGE_SCHEMA: {
    token: '',
    user: {},
  },

  DEFAULT_ICON: 'icon-caidanguanli',
  MENU_ICON_MAPPING: {
    '01': 'icon-home', // 首页
    '02': 'icon-fee', // 费用管理
    '03': 'icon-shenqing', // 日常管理
    '04': 'icon-basic-information_line', // 综合管理
    '05': 'icon-gerenxinxi', // 基础信息管理
    '06': 'icon-kehuguanli', // 客户管理
  },
};

export default constant;
