import lodashGet from 'lodash.get';
import lodashSet from 'lodash.set';
import lodashHas from 'lodash.has';
import constant from '../configs/constant';

const { localStorage } = window;

export class LocalStorageService {
  id = null; // the key of localStorage item

  json = {};

  constructor(id) {
    this.id = id;

    this.#updateJsonByLocalStorage();
  }

  get(keyPath) {
    return lodashGet(this.json, keyPath, null);
  }

  set(keyPath, value) {
    lodashSet(this.json, keyPath, value);

    this.#setJsonStringToLocalStorage();
  }

  has(keyPath) {
    return lodashHas(this.json, keyPath);
  }

  clear() {
    this.json = {};
    this.#setJsonStringToLocalStorage();
  }

  delete(key) {
    Reflect.deleteProperty(this.json, key);
    this.#setJsonStringToLocalStorage();
  }

  #getJsonStringFromLocalStorage() {
    return localStorage.getItem(this.id);
  }

  #getJsonFromLocalStorage() {
    const jsonString = this.#getJsonStringFromLocalStorage();
    let json = {};

    try {
      json = JSON.parse(jsonString) || {};
    } catch (e) {
      console.error(e);
    }

    return json;
  }

  #updateJsonByLocalStorage() {
    this.json = this.#getJsonFromLocalStorage();
  }

  #setJsonStringToLocalStorage() {
    const jsonString = JSON.stringify(this.json);

    localStorage.setItem(this.id, jsonString);
  }
}

const localStorageService = new LocalStorageService(constant.LOCAL_STORAGE_KEY);

export default localStorageService;
