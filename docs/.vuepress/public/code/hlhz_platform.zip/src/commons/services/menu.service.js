/* eslint-disable camelcase */
import cloneDeep from 'lodash.clonedeep';
import constant from '../configs/constant';
import menuApi from './menu.api';
import store from '../../store/store';
import http from '../plugins/http/http';

const { DEFAULT_ICON, MENU_ICON_MAPPING } = constant;

const menusMapping = [
  { url: 'userManage.html', path: '/crm/user-manage' },
  { url: 'systemRoleMenu.html', path: '/crm/role-manage' },
  { url: 'labelBasic.html', path: '/crm/personas-tags' },
  { url: 'customer.html', path: '/crm/customer-manage' },
  { url: 'customerPlan.html', path: '/crm/customer-track' },
  { url: 'contract.html', path: '/crm/contract-manage' },
];

const urlToPath = {};
const pathToUrl = {};

menusMapping.forEach(({ url, path }) => {
  urlToPath[url] = path;
  pathToUrl[path] = url;
});

const menuService = {
  getMenuUrlByPath(path) {
    return pathToUrl[path];
  },

  getPathByMenuUrl(url) {
    return urlToPath[url];
  },
  getCrmMenuList() {
    const api = cloneDeep(menuApi.getMenu);

    return this.getMenuListByApi(api);
  },

  getMenuListByApi(api) {
    // eslint-disable-next-line no-param-reassign
    api.data = {
      uuid: store.getters.uuid,
      clientType: 'web',
      menuType: 'menu',
    };

    return http.request(api)
      .then((data) => {
        const {
          data: menuList,
        } = data;

        return this.formatMenuList(menuList);
      });
  },

  formatMenuList(menuList) {
    const rootMenuList = [];
    const fatherlessMenuList = [];

    // search all parent menus
    menuList.forEach((item) => {
      if (item.c_parent) {
        return;
      }
      const clonedMenu = { ...item };

      clonedMenu.children = [];
      clonedMenu.isCollapsed = true;

      rootMenuList.push(clonedMenu);
    });

    menuList.forEach((item) => {
      const { c_parent } = item;

      // eslint-disable-next-line camelcase
      if (!c_parent) {
        return;
      }
      const clonedMenu = { ...item };

      const parentMenu = rootMenuList.find((menu) => menu.c_code === c_parent);

      if (!parentMenu) {
        fatherlessMenuList.push(clonedMenu);
        return;
      }

      parentMenu.children.push(clonedMenu);
    });

    rootMenuList.forEach((parentMenu) => {
      const { c_icon } = parentMenu;

      // eslint-disable-next-line no-param-reassign
      parentMenu.fontIconClass = MENU_ICON_MAPPING[c_icon] || DEFAULT_ICON;
    });

    return { originMenuList: menuList, rootMenuList, fatherlessMenuList };
  },
};

export default menuService;
