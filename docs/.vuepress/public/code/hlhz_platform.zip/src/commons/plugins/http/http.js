/* eslint-disable class-methods-use-this */
/**
 * http 相关
 *
 * 参考： https://github.com/axios/axios
 */
import cloneDeep from 'lodash.clonedeep';
import lodashSet from 'lodash.set';
import hasIn from 'lodash.hasin';
import qs from 'qs';
import axios from 'axios';

import constant from '../../configs/constant';
import SchemaValidator from './SchemaValidator';
import localStorageService from '../../services/localStorage.service';
import store from '../../../store/store';

export class Http {
  proxy;

  constructor(proxy) {
    this.proxy = proxy;
  }

  async request(api, config = { formatResponse: true }) {
    const formattedApi = this.#formatApi(api);

    this.#validateRequest(formattedApi);

    this.#setTokenHeader(formattedApi);

    const response = await this.#request(formattedApi);

    this.#validateResponse(response, formattedApi);

    this.#checkLoginAuth(response);

    if (config.formatResponse) {
      return this.#formatResponse(response);
    }

    return response;
  }

  #request(config) {
    return this.proxy.request(config);
  }

  #formatApi(api) {
    const formattedApi = cloneDeep(api);

    const {
      method = 'POST',
      data,
      params,
      $formUrlEncoded,
    } = api;

    const lowerCaseMethod = method.toLowerCase();

    if (lowerCaseMethod === 'get') {
      formattedApi.params = params || data;
    }

    if (lowerCaseMethod === 'post' && $formUrlEncoded) {
      formattedApi.data = qs.stringify(data);
    }

    return formattedApi;
  }

  #validateRequest(api) {
    if (api.$formUrlEncoded) {
      return;
    }

    const validatedResult = SchemaValidator.validate(api.data, api.$schema.requestBody);

    this.#handleValidatedResult(validatedResult);
  }

  #validateResponse(response, api) {
    const validatedResult = SchemaValidator.validate(response, api.$schema.responseBody);

    this.#handleValidatedResult(validatedResult);
  }

  #handleValidatedResult(validatedResult) {
    if (validatedResult.success) {
      return;
    }

    console.error('【API schema error】', validatedResult);
  }

  #setTokenHeader(formattedApi) {
    const token = localStorageService.get('token');
    lodashSet(formattedApi, 'headers.token', token);
  }

  #checkLoginAuth(response) {
    const { code } = response;

    if (code === 401) {
      this.#redirectToLogin();
    }
  }

  #redirectToLogin() {
    window.location.hash = '/login';
    store.commit('clearSession');
  }

  #formatResponse(response) {
    if (!this.#isValidJsonResult(response)) {
      return response;
    }

    const { code, msg, data } = response;

    if (code === 200) {
      return Promise.resolve(data);
    }

    return Promise.reject(new Error(msg));
  }

  #isValidJsonResult(res) {
    return hasIn(res, 'code')
      && hasIn(res, 'msg')
      && hasIn(res, 'data');
  }
}

const axiosInstance = axios.create({
  timeout: constant.HTTP_TIMEOUT,
});

axiosInstance.interceptors.response.use(
  (response) => response.data,
  (error) => Promise.reject(error),
);

const http = new Http(axiosInstance);

export default http;
