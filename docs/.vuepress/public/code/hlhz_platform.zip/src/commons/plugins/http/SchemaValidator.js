import isPlainObject from 'lodash.isplainobject';
import isArray from 'lodash.isarray';
import isString from 'lodash.isstring';
import isNumber from 'lodash.isnumber';
import isBoolean from 'lodash.isboolean';
import get from 'lodash.get';

const api = {
  url: '/user',
  method: 'get',
  headers: {
    token: 'yyy',
  },

  requestBodySchema: {
    userId: '123',
  },
  responseBodySchema: {
    status: 200,
    message: 'success',
    data: {
      userId: '123',
      userName: '张三',
    },
  },
};

class SchemaValidator {
  /**
   * validate data by schema
   *
   * @param data
   * @param schema
   * @param paths
   * @returns {{success: boolean, requireType?: string, paths?: string[]}}
   */
  static validateType(data, schema, paths = []) {
    if (isArray(schema)) {
      const requireType = 'array';

      if (!isArray(data)) {
        return { success: false, paths, requireType };
      }

      return this.validateType(data[0], schema[0], [...paths, '0']);
    }

    if (isPlainObject(schema)) {
      const requireType = 'object';

      if (!isPlainObject(data)) {
        return { success: false, paths, requireType };
      }

      const keys = Object.getOwnPropertyNames(schema);

      for (let i = 0; i < keys.length; i += 1) {
        const key = keys[i];
        const result = this.validateType(data[key], schema[key], [...paths, key]);

        if (!result.success) {
          return result;
        }
      }

      return { success: true };
    }

    if (isString(schema)) {
      return { success: isString(data), paths, requireType: 'string' };
    }

    if (isNumber(schema)) {
      return { success: isNumber(data), paths, requireType: 'number' };
    }

    if (isBoolean(schema)) {
      return { success: isBoolean(data), paths, requireType: 'boolean' };
    }

    return { success: true };
  }

  /**
   * validate data by schema
   *
   * @param data {any}
   * @param schema {any}
   * @returns {{ success: boolean, paths?: array, requireType?: string,
   * pathsString?: string, unmatchedValue?: any }}
   */
  static validate(data, schema) {
    const { success, paths, requireType } = this.validateType(data, schema);

    if (!success) {
      const pathsString = paths.join('.');

      const unmatchedValue = get(data, paths);

      return {
        success, paths, requireType, pathsString, unmatchedValue,
      };
    }

    return { success };
  }
}

export default SchemaValidator;
