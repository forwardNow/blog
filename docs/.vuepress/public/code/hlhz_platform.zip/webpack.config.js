/* eslint-disable no-use-before-define,no-unused-vars,arrow-body-style */
const path = require('path');
const { DefinePlugin } = require('webpack');
const { VueLoaderPlugin } = require('vue-loader');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const { BundleAnalyzerPlugin } = require('webpack-bundle-analyzer');
const CopyWebpackPlugin = require('copy-webpack-plugin');
const ZipWebpackPlugin = require('zip-webpack-plugin');
const moment = require('moment');

const config = require('./build/config');
const proxy = require('./build/proxy');

const { ENV } = process.env;

const isDev = ENV === config.ENV.DEV;
const isProd = !isDev; // config.ENV.PROD or config.ENV.TEST

const prodHash = '.[contenthash]';
const devHash = '';
const hash = isProd ? prodHash : devHash;

module.exports = {
  mode: isDev ? 'development' : 'production',

  devtool: isDev ? 'source-map' : false,

  // stats: 'detailed',
  stats: 'minimal',

  resolve: {
    extensions: ['.js', '.json', '.jsx', '.mjs'],
  },

  entry: {
    main: './src/main.js',
    // test: './test/test.js',
  },

  output: {
    path: path.resolve(__dirname, 'dist'),
    filename: `[id]/[name]${hash}.js`,

    // 非初始（non-initial）chunk 文件的名称，按需加载的 chunk 文件
    chunkFilename: `[id]/[name]${hash}.js`,
    clean: true,
  },

  devServer: {
    port: 8080,
    open: ['index.html'],
    hot: true,
    static: true, // default `${root}/public`
    proxy: {
      // /hlhz_basicInfo/** --> http://10.88.0.13:28082/hlhz_basicInfo/**
      ...proxy,
    },
  },

  module: {
    rules: [
      {
        test: /\.m?js$/,
        exclude: /node_modules/,
        use: ['babel-loader'],
      },
      {
        test: /test\.js$/,
        use: 'mocha-loader',
        exclude: /node_modules/,
      },
      {
        test: /\.vue$/,
        use: ['vue-loader'],
      },
      {
        test: /\.css$/i,
        use: [...getCssLoaders()],
      },
      {
        test: /\.less$/i,
        use: [...getLessLoaders()],
      },
      {
        test: /\.scss$/i,
        use: [...getScssLoaders()],
      },

      {
        test: /\.(jpe?g|png|svg|gif)/i,
        ...getAssetOptions(),
      },

      {
        test: /\.(ttf|eot|woff|woff2)$/,
        ...getAssetOptions(),
      },
    ],
  },

  plugins: [
    new DefinePlugin({
      'process.env.ENV': JSON.stringify(ENV),
    }),

    new MiniCssExtractPlugin({
      filename: `[id]/[name]${hash}.css`,
    }),

    new HtmlWebpackPlugin({
      filename: 'index.html',
      chunks: ['main'],
      inject: false,
      template: path.resolve(__dirname, './src/index.html'),
    }),

    new VueLoaderPlugin(),

    new CopyWebpackPlugin({ patterns: ['public'] }),

    isProd ? new ZipWebpackPlugin({
      path: path.resolve(__dirname, 'dist-zip'),
      filename: (function getFilename() {
        // /Users/mjr => mjr
        const projectName = __dirname.replace(/.*[/\\]([a-zA-Z0-9-_]+)$/i, '$1');
        const date = moment().format('YYYY-MM-DD_HH[h]mm[m]ss[s]');
        return `${projectName}_${ENV}_${date}`;
      }()),
    }) : null,

    // isProd ? new BundleAnalyzerPlugin() : null,
  ].filter((i) => i),

  optimization: {
    moduleIds: 'named',
    chunkIds: 'named',
    runtimeChunk: {
      name: 'runtime',
    },
    splitChunks: {
      cacheGroups: {
        vendors: {
          test: /[\\/]node_modules[\\/]/,
          name: 'vendors',
          chunks: 'all',
          priority: -10,
        },
        commons: {
          name: 'commons',
          chunks: 'all',
          minChunks: 2,
          priority: -11,
        },
      },
    },
  },
};

// --

function getAssetOptions() {
  return {
    type: 'asset',
    generator: {
      filename({ filename }) {
        // const namespace = filename.replace(/^src[/\\]([a-z0-9_-]+)[/\\].*/i, '$1');
        //
        // return `${namespace}/images/[name]${hash}.[ext]`;
        // return `images/[name]${hash}.[ext]`;
        return `images/[name]${prodHash}.[ext]`;
      },
    },
    parser: {
      dataUrlCondition: {
        maxSize: 8 * 1024, // 限制于 8kb
      },
    },
  };
}

function getScssLoaders() {
  return getCssLoaders([
    {
      loader: 'sass-loader',
      options: {
        sourceMap: true,
      },
    },
  ]);
}

function getLessLoaders() {
  return getCssLoaders([
    {
      loader: 'less-loader',
      options: {
        sourceMap: true,
      },
    },
  ]);
}

function getCssLoaders(loaders = []) {
  return [
    {
      loader: MiniCssExtractPlugin.loader,
      options: {
        publicPath: '../',
      },
    },

    {
      loader: 'css-loader',
      options: {
        sourceMap: true,
      },
    },

    {
      loader: 'postcss-loader',
      options: {
        sourceMap: true,
        postcssOptions: {
          plugins: [
            // eslint-disable-next-line global-require
            [require('postcss-preset-env')()],
          ],
        },
      },
    },

    ...loaders,
  ];
}
