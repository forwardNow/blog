module.exports = {
  env: {
    browser: true,
    es2021: true,
    node: true,
  },
  extends: [
    'airbnb',
    'plugin:vue/recommended',
  ],

  parser: 'vue-eslint-parser',

  parserOptions: {
    parser: '@babel/eslint-parser',
    ecmaVersion: 12,
    sourceType: 'module',
  },

  rules: {
    complexity: [
      'error',
      {
        max: 15,
      },
    ],
    'vue/multi-word-component-names': 'off',
  },
};
