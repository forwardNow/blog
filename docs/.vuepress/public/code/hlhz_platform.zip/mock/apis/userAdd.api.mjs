const userAddApi = {
  getUsers: {
    url: '/hlhz_crm_plus/userManage/getUsers',
    method: 'post',
    data: {},

    $schema: {
      requestBody: null,
      responseBody: {
        code: 200,
        msg: '操作成功',
        data: [{
          c_user: 'wuqinfei',
          c_name: '吴钦飞',
          c_password: '1f0e3557e1d29f21612d15f67b9b46af',
          c_uuid: '51ef29af-b26e-4f34-946d-8133a81cea95',
          c_state: 'Y',
          c_dept: '8',
          c_dept_arr: '6,8',
          c_position: '前端',
          c_phone: '',
          c_email: '',
          c_is_virtual: '0',
          c_is_daily: '1',
          c_superior: 'E7A23F0AC53B4B45099437A380D20D9462F184EF52F0A728B45C0A82748E6276',
          c_station: '067',
          c_join_date: '2021-12-01',
          c_leave_date: '',
          c_start_work_time: '2017-12-01',
          c_contract_expir_date: '',
          c_formal_time: '',
          c_type: '1',
          dept: '产品开发部',
          c_order: '2',
        }],
      },
    },
  },
};

export default userAddApi;
