const menuApi = {
  getMenu: {
    url: '/hlhz_crm_plus/systemConfig/getMenu', // /hlhz_crm_plus 10.88.0.13:28096
    method: 'post',
    data: {},

    $formUrlEncoded: true,

    $schema: {
      requestBody: {
        uuid: '29C523B43F710DF1E1B805D41123671F67C8014A214D35ED3F867DE2C917A4DE',
        clientType: 'web',
        menuType: 'menu',
      },
      responseBody: {
        code: 200,
        msg: '操作成功',
        data: {
          buttons: [{
            c_menu: 'menu_b1', c_button: 'customerDistribution', c_name: '客户分配', c_system: 'cp001',
          }],
          data: [{
            c_code: 'menu_a0', c_name: '基础信息管理', c_parent: '', c_icon: '05', c_url: '', c_state: '1', c_order: '1',
          }, {
            c_code: 'menu_a1', c_name: '用户管理', c_parent: 'menu_a0', c_icon: '', c_url: 'userManage.html', c_state: '1', c_order: '1',
          }, {
            c_code: 'menu_a2', c_name: '角色权限管理', c_parent: 'menu_a0', c_icon: '', c_url: 'systemRoleMenu.html', c_state: '1', c_order: '2',
          }, {
            c_code: 'menu_a3', c_name: '画像标签', c_parent: 'menu_a0', c_icon: '', c_url: 'labelBasic.html', c_state: '1', c_order: '3',
          }, {
            c_code: 'menu_b0', c_name: '客户管理', c_parent: '', c_icon: '06', c_url: '', c_state: '1', c_order: '2',
          }, {
            c_code: 'menu_b1', c_name: '客户信息管理', c_parent: 'menu_b0', c_icon: '', c_url: 'customer.html', c_state: '1', c_order: '1',
          }, {
            c_code: 'menu_b2', c_name: '客户跟进', c_parent: 'menu_b0', c_icon: '', c_url: 'customerPlan.html', c_state: '1', c_order: '2',
          }, {
            c_code: 'menu_b3', c_name: '合同管理', c_parent: 'menu_b0', c_icon: '', c_url: 'contract.html', c_state: '1', c_order: '3',
          }],
        },
      },
    },
  },
};

export default menuApi;
