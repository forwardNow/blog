const homeApi = {
  getSystems: {
    url: '/hlhz_basicInfo/systemConfig/getSytemByUser',
    method: 'post',
    data: {},

    $formUrlEncoded: true,

    $schema: {
      requestBody: {
        uuid: 'xxx',
        type: '',
      },
      responseBody: {
        code: 200,
        msg: '操作成功',
        data: [{
          c_code: 'cp015', c_name: 'CRM2.0', c_describe: '6', c_url: '../hlhz_crm_plus/index.html', c_type: 'web', c_img_url: 'group1/M00/00/13/ClgAEmCuAQ6ASl3CAAAiXDJ5pa0520.PNG', c_request_url: 'hlhz_crm_plus', c_phone_url: '', c_is_show: '1', c_db_redis_key: 'crmPlus', c_db_ralation_key: 'crmPlus', c_db_time_key: 'crmPlus',
        }, {
          c_code: 'cp016', c_name: 'OA4.0', c_describe: '6', c_url: '../hlhz_oa_fourth/index.html', c_type: 'web', c_img_url: 'group1/M00/00/13/ClgAEmCuAQ6ASl3CAAAiXDJ5pa0520.PNG', c_request_url: 'hlhz_oa_fourth', c_phone_url: '', c_is_show: '1', c_db_redis_key: 'oaFourth', c_db_ralation_key: 'oaFourth', c_db_time_key: 'oaFourth',
        }],
      },
    },
  },
};

export default homeApi;
