const userManageApi = {
  getList: {
    url: '/hlhz_crm_plus/userManage/getList',
    method: 'post',
    data: {},

    $formUrlEncoded: false,

    $schema: {
      requestBody: {
        customParam: {
          loginUser: 'hlhz_admin',
        },
        data: [
          { code: 'c_name', value: '', symbol: '=' },
        ],
        page: 1,
        limit: 10,
      },
      responseBody: {
        code: 200,
        msg: '操作成功',
        data: {
          data: [
            {
              c_uuid: '1381B73CF35919EA5F3834F6BB1D744725F780D8594875CA2C510D385230F9EC',
              c_user: 'peimenghao',
              c_state: '1',
              c_state_name: '启用',
              c_name: '裴梦浩',
              c_password: '1f0e3557e1d29f21612d15f67b9b46af',
              c_dept: '8',
              c_dept_arr: '6,8',
              c_position: '开发',
              c_phone: '13312341234',
              c_email: 'zhanghongxia@henrywaltz.cn',
              c_is_virtual: '0',
              c_is_daily: '1',
              c_superior: 'E7A23F0AC53B4B45099437A380D20D9462F184EF52F0A728B45C0A82748E6276',
              c_station: '8',
              c_join_date: '2020-07-01',
              c_leave_date: '',
              c_start_work_time: '2021-07-28',
              c_contract_expir_date: '',
              c_formal_time: '2021-07-19',
              c_type: '1',
              dept: '产品开发部',
              c_order: '2',
            },
          ],
          count: 15,
        },
      },
    },
  },
};

export default userManageApi;
