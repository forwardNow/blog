const loginApi = {
  login: {
    url: '/hlhz_basicInfo/login/loginIndex', // hlhz_basicInfo 10.88.0.13:28082
    method: 'post',
    data: {},

    $formUrlEncoded: true,

    $schema: {
      requestBody: {
        user: 'hlhz_admin',
        password: '123456',
        clientType: 'pc',
      },
      responseBody: {
        code: 200,
        msg: '操作成功',
        data: {
          user: {
            c_user: 'hlhz_admin',
            c_name: '管理员',
            c_password: '1f0e3557e1d29f21612d15f67b9b46af',
            c_uuid: '29C523B43F710DF1E1B805D41123671F67C8014A214D35ED3F867DE2C917A4DE',
            c_state: 'Y',
            c_dept: '8',
            c_dept_arr: '1,3,6,8',
            c_position: '管理员',
            // c_phone: '',
            // c_email: '',
            c_is_virtual: '1',
            c_is_daily: '0',
            c_superior: '',
            c_station: '000',
            c_join_date: '2020-07-01',
            c_leave_date: '2021-07-07',
            c_start_work_time: '2021-07-06',
            c_contract_expir_date: '',
            c_formal_time: '',
            c_type: '1',
          },
          token: 'eyJ0eXA',
        },
      },
    },
  },
};

export default loginApi;
