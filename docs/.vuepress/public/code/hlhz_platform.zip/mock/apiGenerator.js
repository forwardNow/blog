/* eslint-disable import/no-extraneous-dependencies,
import/extensions,import/no-relative-packages,no-use-before-define */

const fs = require('fs');
const path = require('path');

const apiGenerator = {
  src: {
    dir: './src',
    apiSearchString: '.api.js',

    filePaths: [],
  },

  mock: {
    dir: './mock/apis',

    filePaths: [],
  },

  init() {
    this.getApiFilePathsOfSrc();

    this.createMockApiDir();

    this.copySrcApiFilesToMockApiDir();
  },

  getApiFilePathsOfSrc() {
    const { dir, apiSearchString } = this.src;

    this.src.filePaths = this.getFilePaths(dir, apiSearchString);
  },

  getFilePaths(dir, searchString = '') {
    const filePaths = [];

    const traverseDir = (dirPath) => {
      if (!fs.existsSync(dirPath)) {
        console.log('no dir ', dirPath);
        return;
      }

      const filenames = fs.readdirSync(dirPath);

      filenames.forEach((filename) => {
        const filepath = path.join(dirPath, filename);

        const fileState = fs.lstatSync(filepath);

        if (fileState.isDirectory()) {
          traverseDir(filepath); // recurse
          return;
        }

        if (!filepath.includes(searchString)) {
          return;
        }

        filePaths.push(filepath);
      });
    };

    traverseDir(dir, searchString);

    return filePaths;
  },

  createMockApiDir() {
    this.createDir(this.mock.dir);
  },

  createDir(dir, removeWhenExist = true) {
    try {
      if (fs.existsSync(dir)) {
        console.log(`${dir} directory already exists.`);

        if (removeWhenExist) {
          console.log(`${dir} directory was removed.`);
          this.removeDir(dir);
        }
      }
      fs.mkdirSync(dir);
      console.log(`${dir} directory is created.`);
    } catch (err) {
      console.log(err);
    }
  },

  removeDir(dir) {
    fs.rmSync(dir, { recursive: true });
  },

  copySrcApiFilesToMockApiDir() {
    this.src.filePaths.forEach((srcFilePath) => {
      const mockFilePath = this.getMockFilePath(srcFilePath);

      this.mock.filePaths.push(mockFilePath);

      fs.copyFileSync(srcFilePath, mockFilePath);

      console.log(`copy ${srcFilePath} --> ${mockFilePath}`);
    });
  },

  getMockFilePath(srcFilePath) {
    const {
      mock: {
        dir: mockApiDir,
      },
    } = this;
    const basename = path.basename(srcFilePath, '.js');
    const moduleFilename = `${basename}.mjs`;
    const mockFilePath = path.join(mockApiDir, moduleFilename);

    return mockFilePath;
  },
};

apiGenerator.init();

module.exports = apiGenerator;
