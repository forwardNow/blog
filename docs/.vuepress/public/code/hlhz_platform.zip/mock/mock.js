const apiGenerator = require('./apiGenerator');
const server = require('./server');

apiGenerator.init();
server.init();
