const fs = require('fs');
const express = require('express');

const server = {
  app: express(),

  mockApiDir: './mock/apis',
  relPath: './apis',

  init() {
    this.initRouter();
    this.listen();
  },

  initRouter() {
    this.registerRootRoute();

    this.loadApiFiles();
  },

  registerRootRoute() {
    this.app.get('/', (req, res) => {
      res.send('hello world');
    });
  },

  loadApiFiles() {
    const { mockApiDir, relPath } = this;
    const filenames = fs.readdirSync(mockApiDir);

    const apiFilePaths = filenames.map((filename) => `${relPath}/${filename}`);

    apiFilePaths.forEach(async (filePath) => {
      const module = await import(filePath);

      const { default: apis } = module;

      Object.getOwnPropertyNames(apis).forEach((key) => {
        const api = apis[key];

        const {
          url,
          method,
          $schema: {
            responseBody,
          },
        } = api;

        const m = method.toLowerCase();

        this.app[m](url, (req, res) => {
          res.status(200).json(responseBody);
        });
      });
    });
  },

  listen() {
    this.app.listen(3000, () => {
      console.log('http://localhost:3000');
    });
  },
};

module.exports = server;
