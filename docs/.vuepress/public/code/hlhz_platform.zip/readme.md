# 前端构建

## 1. 目的

编写此文档的目的是为了说明**如何使用 [webpack5](https://webpack.js.org/) 构建的前端工程**。

## 2. 环境

运行此工程需要 node.js 环境，安装步骤：

1. 下载（[https://nodejs.org/en/](https://nodejs.org/en/)）
   * 建议下载 LTS（长期支持）版本
   * ![下载](doc/assets/images/01-nodejs-downlad.png)
   
2. 安装
   * 下一步 -> 下一步 -> ... -> 安装完成

3. 验证
   * 查看 CMD 命令是否有效： `node -v` 、 `npm -v`
   * ![cmd](doc/assets/images/02-nodejs-cmd.png)

## 3. 运行

```shell
# 切换到（前端）项目根目录
cd /D D:\dev\projects\hlhz_platform

# 安装项目依赖
npm i

# （开发环境）启动 dev-server 
npm run dev

# （生产环境）编译（打包）
npm run build
```

## 4. 目录

```text
hlhz_platform/
    src/                # 源码目录

    public/             # 静态资源（构建时会原封不动拷贝到 dist 目录）

    dist/               # 编译目录
    dist-zip/           # 执行编译后，会将 `dist/` 下的所有资源压缩成 zip 包

    build/              # webpack 构建相关

    node_modules/       # npm 包 所在目录
    .cache/             # npm 缓存

    .browserslistrc     # 设置（JS、CSS）兼容的浏览器及版本
    .eslintrc.js        # ESLint（代码风格校验）
    .npmrc              # npm 配置
    babel.config.js     # babel（将最新JS语法转为浏览器可以解析的兼容版本）
    package.json        # 项目配置（描述）文件
    package-lock.json   # npm 包版本锁
    readme.md           # 文档
    webpack.config.js   # webpack 配置文件
```

### 4.1. src/

```text
src/
    common/     # 公共
    pages/      # 页面
```

#### 4.1.1. src/common/

```text
common/            
    assets/     # 资源
    components/ # 组件
    config/     # 配置
    plugins/    # 插件
    style/      # 样式
```

作用：

* 公共部分（多个页面都会用到的资源、脚本）


#### 4.1.2. src/pages/

```text
pages/                  
    about-us/           # `about-us`
        about-us.html   # `about-us` 的页面
        about-us.js     # `about-us` 的脚本（入口文件， main.js）
    home/
        components/
        home.html
        home.js
```

作用：

* 定义页面

说明：

* `pages/` 目录的直接子目录（如`about-us`）才会判定为“页面”。

(TODO)判定页面的条件：

1. 包含 `页面名A.html`；
2. `页面名A.html` 的父目录名称也是 `页面名A`

### 4.2. public/

作用：

* 静态资源目录，不会被 webpack 编译
* `public/` 下的所有内容会原封不动的拷贝到 `dist/` 目录

用途：

* 存放（不能被 webpack 编译）第三方插件
* 存放 CDN 上的相关资源
* 其他

## 5. （编译）打包

作用：

1. 将源代码（`src/`下所有内容）编译成浏览器可以识别的资源（js/css/html/...）
2. 将各个页面的资源编译到 `dist/` 目录
3. `dist/` 目录的所有资源压缩到 zip 文件，存放在 `dist-zip/` 目录

命令（npm scripts）：

```shell
# test 环境打包
npm run build:test

# prod 环境打包
npm run build:prod
```

## 6. 开发

### 6.1. 环境（`ENV`）

预定义了三种环境

* `dev`
* `test`
* `prod`

作用：

* 通过 npm scripts 把 `ENV` 传给构建脚本
* 无需更改源代码即可编译到不同的环境

### 6.2. 页面

```text
src/
    pages/
        home/           # 页面
            home.html   # 模板
            home.js     # 脚本
```

### 6.3. 配置

配置文件位置：

[src/common/config/constant.js](src/common/config/constant.js)

```text
src/
    common/
        config/
            constant.js
```

作用：

* 抽取硬编码的配置，便于后期迭代更新
* 设置多环境（dev/test/prod）的配置（如 `api_base_path`）

### 6.4. 请求

### 6.5. 样式

### 6.6. 代理

### 6.7. ESLint

说明：

* 官网 [https://eslint.org/](https://eslint.org/)
* JavaScript 代码检测工具

作用：

* 统一 JavaScript 代码风格
* 避免滥用有隐患的 JavaScript 语法