'use strict';

const { series, src, dest } = require('gulp');
const sass = require('gulp-dart-sass');
const autoprefixer = require('gulp-autoprefixer');
const cssmin = require('gulp-cssmin');
const sourcemaps = require('gulp-sourcemaps');
const rename = require('gulp-rename');

const { theme = '' } = process.env;

const themePath = `/theme/${theme}`

function compile() {
  return src(`./src${themePath}/*.scss`)
    .pipe(sourcemaps.init({}))
    .pipe(sass.sync().on('error', sass.logError))
    .pipe(autoprefixer({
      overrideBrowserslist: ['ie > 9', 'last 2 versions'],
      cascade: false
    }))
    .pipe(sourcemaps.write())
    .pipe(dest(`./lib${themePath}`))
    .pipe(cssmin())
    .pipe(rename({suffix: '.min'}))
    .pipe(dest(`./lib${themePath}`));
}

function copyfont() {
  return src('./src/fonts/**')
    .pipe(cssmin())
    .pipe(dest(`./lib${themePath}/fonts`));
}

exports.build = series(compile, copyfont);
